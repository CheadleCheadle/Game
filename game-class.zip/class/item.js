
class Item {
  constructor(name, description) {
    this.name = name;
    this.description = description;
  }
}

module.exports = {
  Item,
};
